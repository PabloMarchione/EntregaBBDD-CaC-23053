CREATE SCHEMA entrega_bbdd;
USE entrega_bbdd;

CREATE TABLE personas(  
    id INT NOT NULL auto_increment PRIMARY KEY,  
    nombre VARCHAR(40) NOT NULL,  
    apellido VARCHAR(40) NOT NULL,
    edad TINYINT NOT NULL,
    fecha TIMESTAMP NOT NULL DEFAULT(CURRENT_TIMESTAMP()),
    provincia VARCHAR(30) NOT NULL
); 

INSERT INTO personas values
(null,"Ramon","Perez",75,DEFAULT,"Cordoba"),
(null,"Lisandro","Maciel",29,DEFAULT,"Formosa"),
(null,"Celeste","Dupont",41,DEFAULT,"Santa Fe"),
(null,"Maria Rosa","Lloris",66,DEFAULT,"Salta"),
(null,"Evaristo","Ayala",33,DEFAULT,"San Luis");

SELECT * FROM personas;